package com.tapioca.BE.application.dto.response.team;

public record TeamsDto(
        String teamName,
        String teamCode
) {
}
