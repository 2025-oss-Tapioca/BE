package com.tapioca.BE.application.dto.request.team;

public record CreateTeamRequestDto(
        String teamName
) {}
