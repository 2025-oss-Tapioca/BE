package com.tapioca.BE.application.dto.request.gpt;

public record GptRequestDto(
        String userRequest
) {
}
