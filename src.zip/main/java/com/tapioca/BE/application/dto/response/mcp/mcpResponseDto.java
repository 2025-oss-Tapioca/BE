package com.tapioca.BE.application.dto.response.mcp;

public record mcpResponseDto() {
}
