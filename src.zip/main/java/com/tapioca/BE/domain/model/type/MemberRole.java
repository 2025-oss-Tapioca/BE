package com.tapioca.BE.domain.model.type;

public enum MemberRole {
    ADMIN,
    USER
}
