package com.tapioca.BE.domain.model.type;

public enum LinkType {
    ONE_TO_ONE,
    ONE_TO_MANY,
}
