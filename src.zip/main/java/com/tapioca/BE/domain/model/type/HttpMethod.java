package com.tapioca.BE.domain.model.type;

public enum HttpMethod {
    POST,
    GET,
    DELETE,
    PATCH,
    PUT
}
